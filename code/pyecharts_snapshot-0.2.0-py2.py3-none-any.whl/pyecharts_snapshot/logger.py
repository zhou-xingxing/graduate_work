VERBOSE = True


def info(message):
    if VERBOSE:
        print(message)


def warn(message):
    print(message)
